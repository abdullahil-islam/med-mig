# -*- coding: utf-8 -*-

from . import res_partner
from . import sale_order
from . import product
from . import sale_order_tag
from . import pricelist
from . import register_payment
from . import account_payment
from . import stock_picking
# from . import res_config_setting
