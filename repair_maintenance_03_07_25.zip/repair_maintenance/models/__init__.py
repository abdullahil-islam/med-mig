# -*- coding: utf-8 -*-

from . import account_invoice
from . import res_users
from . import product
from . import partner
from . import maintenance
from . import ir_attachment
from . import repair
from . import project_project
from . import project_task_template
from . import hr_employee