# -*- coding: utf-8 -*-

from . import repair_report_wizard
from . import maintenance_report_wizard
