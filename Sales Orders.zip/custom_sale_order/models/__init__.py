# -*- coding: utf-8 -*-

from . import sale_approval_hierarchy, sale_order, stock_picking, res_config_setting, quotation_template, payment_terms
